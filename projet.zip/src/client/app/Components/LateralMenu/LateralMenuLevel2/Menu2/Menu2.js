import React, { Component } from 'react';

class Menu2 extends Component {
    render(){
        return (
            <div className="MenuLeft">
                etters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default mod
            </div>
        )
    }
}
export default Menu2;