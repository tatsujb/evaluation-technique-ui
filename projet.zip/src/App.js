import React, { Component } from 'react';
import Home from './client/app/Home';
// Load Comfortaa typeface
import ('typeface-comfortaa');

class App extends Component {
  render() {
    return (
        <Home/>
    );
  }
}

export default App;
